xbmc-xstream-plugin
===================

a fork of the well-known xbmc-plugin for online-streaming services
this fork was created, since the contact to the former (or current?) author seems to
be very difficult to establish and i had no way of sharing my streamallthis-plugin for xstream.

also - im not such a big fan of where the current code is hosted and its just a pain in the ass
to find the current version.... therefore github looked like the right place.

contributions are welcome and appreciated.
send me a note.
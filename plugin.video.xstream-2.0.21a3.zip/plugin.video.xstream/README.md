a fork of the well-known xbmc-plugin for online-streaming services.  
contributions are welcome and appreciated.  


why the fork ?
--------------
* contact to the former (or current?) author(s) seems to be very difficult to establish
* no way of contributing newly added plugins
* maintenance of the package seemed to be very sporadic and unreliable.
* code layout was a mess (and we're dealing with python here... ;) so that says smth..)
* the plugin itself is great - so dont reinvent smth good - just get it back on track


status
------

current development status: 2.0.21-alpha  
latest version: 2.0.21a3  
tested on: appletv 2, osx 10.8.3  


former author(s) - up till 2.0.19:
----------------------------------
Lynx187 (originator: murphy, MaxMustermann)


plugins :: working
------------------

* streamallthis_ch  - full
* kinox_to          - full
* kinokiste_com     - full
* bundesliga_de     - full
* burning_series    - full
* serienjunkies_org - full

plugins :: untested / defunct   
-----------------------------

* anime-proxer.me - broken
* anime-stream24.com - broken
* movie2k.to - broken
* gstream_in - broken


disclaimer:
-----------

this whole project serves only educational purposes. it shall by no means be actually used
or serve to encourage anyone for circumventing hoster-applied playing requirements.